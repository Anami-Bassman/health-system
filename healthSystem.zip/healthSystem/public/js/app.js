//const API_BASE_URL = 'http://localhost:8000/api';
const API_BASE_URL = 'http://127.0.0.1:8000/api';

const token = '3|UWUDmfDwcRMq3l0mCYgvYFVWJ1sDn9dC6CvXOdmk'; // token from api/login

// Helper function for API requests
async function apiRequest(endpoint, method = 'GET', data = null) {
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
    };
    const config = { method, headers };
    if (data) config.body = JSON.stringify(data);

    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    if (!response.ok) throw new Error('Request failed');
    return response.json();
}

// Create Program
document.getElementById('programForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('programName').value;
    const description = document.getElementById('programDescription').value;

    // Log the values being sent
    console.log('Program Name:', name);
    console.log('Program Description:', description);

    try {
        await apiRequest('/programs', 'POST', { name, description });
        alert('Program created!');
        e.target.reset();
    } catch (error) {
        alert('Error creating program');
    }
});


// Register Client
document.getElementById('clientForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
        first_name: document.getElementById('firstName').value,
        last_name: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        date_of_birth: document.getElementById('dob').value,
    };

    try {
        await apiRequest('/clients', 'POST', data);
        alert('Client registered!');
        e.target.reset();
    } catch (error) {
        alert('Error registering client');
    }
});

// Enroll Client
document.getElementById('enrollmentForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
        client_id: document.getElementById('clientId').value,
        program_id: document.getElementById('programId').value,
        enrollment_date: new Date().toISOString().split('T')[0],
    };

    try {
        await apiRequest('/enrollments', 'POST', data);
        alert('Client enrolled!');
        e.target.reset();
    } catch (error) {
        alert('Error enrolling client');
    }
});

// Search Clients
document.getElementById('searchInput').addEventListener('input', async (e) => {
    const query = e.target.value;
    try {
        const clients = await apiRequest(`/clients?search=${query}`);
        const clientList = document.getElementById('clientList');
        clientList.innerHTML = clients.map(client => `
            <div class="card mb-2">
                <div class="card-body">
                    ${client.first_name} ${client.last_name} (${client.email})
                </div>
            </div>
        `).join('');
    } catch (error) {
        document.getElementById('clientList').innerHTML = '<p>Error searching clients</p>';
    }
});

// View Client Profile
document.getElementById('viewProfileBtn').addEventListener('click', async () => {
    const clientId = document.getElementById('clientProfileId').value;
    try {
        const client = await apiRequest(`/clients/${clientId}`);
        const clientProfile = document.getElementById('clientProfile');
        clientProfile.innerHTML = `
            <h4>${client.first_name} ${client.last_name}</h4>
            <p>Email: ${client.email}</p>
            <p>Phone: ${client.phone || 'N/A'}</p>
            <p>Date of Birth: ${client.date_of_birth}</p>
            <h5>Enrolled Programs:</h5>
            <ul>
                ${client.programs.map(program => `<li>${program.name}</li>`).join('')}
            </ul>
        `;
    } catch (error) {
        document.getElementById('clientProfile').innerHTML = '<p>Error loading profile</p>';
    }
});
